//POTETE AGGIUNGERE VARIABILI GLOBALI
const prodotti = {};
let objNuovoProd = {};


//DA COMPLETARE (Connettersi al server chiedendo dei singoli servizi)
window.onload = async ()=>{

    caricaSettore();


    let txtQta;
    let btnInserisci = document.getElementById("btnAggiungiProd");

    let sel = document.getElementById("selProdotto");
    btnInserisci.addEventListener("click", async function () {
        txtQta = document.getElementById("txtQta");

        objNuovoProd = { parola: txtQta.value, settore: sel.value };
        console.log(objNuovoProd);

        let req = await fetch("http://localhost:1337/caricaParolaSuFile", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(objNuovoProd),

        });
    });


}

//DA COMPLETARE
async function caricaSettore()
{

    let sel1 = document.getElementById("selUt");
    let sel2 = document.getElementById("selNegozio");
    let sel3 = document.getElementById("sel");
    let opt1 = document.createElement("option");
    let opt2 = document.createElement("option");
    let opt3 = document.createElement("option");

    let req = await fetch("http://localhost:1337/caricaSettori", {
        method: "GET",
    });

    let res = await req.json();
    console.log(res);

    for (let s of res)
    {

        opt1 = document.createElement("option");
        opt1.value = s.prodotto;
        opt1.innerHTML = s.prodotto;
        opt2 = document.createElement("option");
        opt2.value = s.prodotto;
        opt2.innerHTML = s.prodotto;
        opt3 = document.createElement("option");
        opt3.value = s.prodotto;
        opt3.innerHTML = s.prodotto;
        sel1.appendChild(opt1);
        sel2.appendChild(opt2);
        sel2.appendChild(opt3);

    }

}


//POTETE INSERIRE ALTRE FUNZIO

function disegnaGrafico(canvas, tipo, data, label){
    let dati = {
        labels: [],
        datasets: [{
            label: label,
            data: []
        }]
    };
    console.log(data);

    if(document.getElementById('canvasMulti') == canvas){
        data = data.spese;
        for(let i = 0; i < data.length; i++){
            console.log(data[i]);
            dati.labels.push(data[i].data);
            dati.datasets[0].data.push(data[i].prodotti);
        }
    }
    console.log(dati);
    Chart.defaults.color = '#FFF';
    let grafico = new Chart(canvas, {
        type: tipo,
        data: dati,
        options: {
            plugins: {
                legend: {
                    display: false
                },
            }
        }});
}