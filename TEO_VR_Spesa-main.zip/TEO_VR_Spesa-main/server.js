const http = require("http");
const url = require("url");
const fs = require("fs");
const { json } = require("stream/consumers");
let header = { "Access-Control-Allow-Origin": "*" };
let corpoBusta = "";
let objTrovato = [];
let objS = [];
let objSettore = [];
let objParoleSettore = [];
let objNuovaParola = [];
let nSettorePadre2;


var server = http.createServer(function (richiesta, risposta) {
    let indirizzo = richiesta.headers.host + richiesta.url;
    let infoUrl = url.parse(indirizzo, true);

    console.log(infoUrl.pathname);
    switch (infoUrl.pathname) {


        case "/":
            contesto = { risp: risposta, tipo: "text/html" };
            fs.readFile("index.html", inviaFile.bind(contesto));
            break;



        case "/prodotti":
            richiesta.on("data", (dato) => {
                //console.log("DATA:"+dato);
                corpoBusta += dato;

                fs.readFile("dati.json", function (err, dati) {

                    if (err)
                    {
                        rispondi(risposta, "text/plain", 404, "File non trovato");
                    }
                    else
                    {
                        let dat = JSON.parse(dati);
                        //console.log(diz)
                        for (let par in dat)
                        {

                            if (dat[par].nome.includes(JSON.parse(corpoBusta).text))
                            {
                                objTrovato.push({ nome: dat[par].nome });
                            }
                        }

                        //console.log(objTrovato)
                        rispondi(
                            risposta,
                            "application/json",
                            200,
                            JSON.stringify(objTrovato)
                        );

                        objTrovato = [];
                        corpoBusta = "";

                    }
                });
            });

            break;



        case "/index.js":
            contesto = { risp: risposta, tipo: "text/javascript" };
            fs.readFile("index.js", inviaFile.bind(contesto));
            break;



        case "/index.css":
            contesto = { risp: risposta, tipo: "text/css" };
            fs.readFile("index.css", inviaFile.bind(contesto));
            break;



        case "/caricaSettori":
            fs.readFile("dati.json", function (err, dati) {

                if (err)
                {
                    rispondi(risposta, "text/plain", 404, "File non trovato");
                }
                else
                {

                    let diz = JSON.parse(dati);
                    //console.log(diz)
                    for (let par in diz)
                    {

                        if ( !objSettore.includes(diz[par].nome) && diz[par].nome == null )
                        {
                            objSettore.push(diz[par].nome);
                        }

                    }

                    for (let set in diz)
                    {

                        for (let item of objSettore)
                        {

                            if (item == diz[set].nome && !objS.includes(item))
                            {
                                objS.push({ nome: set, prodotto: diz[set].nome });
                            }

                        }

                    }

                    //console.log(objS)
                    rispondi(risposta, "application/json", 200, JSON.stringify(objS));
                }
            });

            break;


        case "/caricaParolaSuFile":

            richiesta.on("data", (dato) => {
                corpoBusta += dato;
            });

            richiesta.on("end", () => {
                console.log(corpoBusta);
                fs.readFile("dati.json", function (err, dati) {
                    if (err) {
                        rispondi(risposta, "text/plain", 404, "File non trovato");
                    } else {
                        let diz = JSON.parse(dati);
                        let ultimoIndice = 0;
                        for (let par in diz) {
                            ultimoIndice = par;
                            if (JSON.parse(corpoBusta).settore == diz[par].desc) {
                                nSettorePadre2 = par;
                            }
                        }

                        // Aggiungi direttamente l'elemento al dizionario
                        diz[parseInt(ultimoIndice) + 1] = {
                            nome: JSON.parse(corpoBusta).parola,
                            costo: [parseInt(nSettorePadre2)]
                        };

                        const nuovoContenuto = JSON.stringify(diz, null, 2);

                        fs.writeFile("diz.json", nuovoContenuto, "utf8", function (err) {
                            if (err) {
                                rispondi(
                                    risposta,
                                    "text/plain",
                                    500,
                                    "Errore nella scrittura del file"
                                );
                            } else {
                                console.log(ultimoIndice);
                                rispondi(
                                    risposta,
                                    "text/plain",
                                    200,
                                    "Parola aggiunta con successo"
                                );
                                corpoBusta = "";
                            }
                        });
                    }
                });
            });
            break;



        default:
            //Automaticamente ritorno ogni html richiesto (se esiste)
            //CASO 1 - richiedo html
            if (infoUrl.pathname.includes("html")) {
                contesto = { risp: risposta, tipo: "text/html" };
                fs.readFile(infoUrl.pathname, inviaFile.bind(contesto));
            } else if (infoUrl.pathname.includes("js")) {
                contesto = { risp: risposta, tipo: "text/javascript" };
                fs.readFile(infoUrl.pathname, inviaFile.bind(contesto));
            } else if (infoUrl.pathname.includes("css")) {
                contesto = { risp: risposta, tipo: "text/css" };
                fs.readFile(infoUrl.pathname, inviaFile.bind(contesto));
            } else if (infoUrl.pathname.includes("json")) {
                contesto = { risp: risposta, tipo: "application/json" };
                fs.readFile(infoUrl.pathname, inviaFile.bind(contesto));
            }
            //Caso 2 - risorsa o servizio non esistente
            else
                rispondi(
                    risposta,
                    "text/plain",
                    404,
                    "Nessuna risorsa è stata trovata!"
                );
            break;
    }
});



let porta = 1337;
server.listen(porta);
console.log("Il server è stato avviato sulla porta " + porta);


function rispondi(risposta, contentType, statoRisposta, testo) {
    header["Content-Type"] = contentType;
    risposta.writeHead(statoRisposta, header);
    risposta.write(testo);
    risposta.end();
}


function inviaFile(err, file) {
    if (err) rispondi(this.risp, "text/plain", 404, "File non trovato");
    else rispondi(this.risp, this.tipo, 200, file);
}
